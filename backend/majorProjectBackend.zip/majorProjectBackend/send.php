<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

// Read JSON input from frontend

$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Check if email is provided
if (!isset($data['email'])) {
    echo json_encode(['success' => false, 'message' => 'Email is required']);
    exit;
}

$email = $data['email'];
$user_email=$data['Your Email'];
$mail = new PHPMailer(true);

try {
    // SMTP Configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'asdinsights1234coordinates@gmail.com';
    $mail->Password = 'skbbzxmpkxnrzmnw'; 
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;


    $mail->setFrom('asdinsights1234coordinates@gmail.com', $data['name']);
    $mail->addAddress($email);
    $mail->addReplyTo($user_email);

    
    $mail->isHTML(true);
    $mail->Subject = "Query Regarding Your Application:Fetal Brain Abnormalities Classification";
    $mail->Body = $data['message'];

    if (!$mail->send()) {
        echo json_encode(['success' => false, 'message' => 'Mail not sent: ' . $mail->ErrorInfo]);
        exit;
    }

    echo json_encode(['success' => true, 'message' => 'Mail sent successfully']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Mailer Error: ' . $e->getMessage()]);
}
?>
