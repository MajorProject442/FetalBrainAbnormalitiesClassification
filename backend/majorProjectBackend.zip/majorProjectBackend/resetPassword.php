<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// CORS Headers
header('Access-Control-Allow-Origin: http://localhost:5173'); // Allow requests from React app
header('Access-Control-Allow-Methods: POST, GET, OPTIONS'); // Allow specific HTTP methods
header('Access-Control-Allow-Headers: Content-Type, Authorization'); // Allow specific headers
header('Access-Control-Allow-Credentials: true'); // Optional, if credentials like cookies are needed

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200); // Respond OK for preflight
    exit;
}

header('Content-Type: application/json');

$host = 'localhost';
$username = 'root';
$password = 'n190658';
$database = 'majorproject';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

// Read input data
$data = json_decode(file_get_contents('php://input'), true);

// Debugging: Log received data
file_put_contents('debug.log', "Received data: " . print_r($data, true) . "\n", FILE_APPEND);

if (!isset($data['token'], $data['password'])) {
    file_put_contents('debug.log', "Missing required fields: token or password\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Invalid input. Token and password are required.']);
    exit;
}

$token = trim($data['token']);
$password = trim($data['password']);

// Check if token exists and is not expired
$query = "SELECT user_id, expiry FROM password_resets WHERE token = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    file_put_contents('debug.log', "Token not found in database: $token\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token.']);
    $stmt->close();
    $conn->close();
    exit;
}

$row = $result->fetch_assoc();
$user_id = $row['user_id'];
$expiry = $row['expiry'];

$stmt->close();

file_put_contents('debug.log', "Token expiry: $expiry\n", FILE_APPEND);

if (strtotime($expiry) < time()) {
    file_put_contents('debug.log', "Token has expired\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Token has expired. Please request a new password reset.']);
    // Optionally delete the expired token from the table
    $deleteQuery = "DELETE FROM password_resets WHERE token = ?";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bind_param("s", $token);
    $deleteStmt->execute();
    $deleteStmt->close();
    $conn->close();
    exit;
}

// Hash the new password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Update password in users table
$query = "UPDATE users_t SET password = ? WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("si", $hashedPassword, $user_id);

if ($stmt->execute()) {
    file_put_contents('debug.log', "Password updated successfully\n", FILE_APPEND);
    // Delete the used token from password_resets table
    $deleteQuery = "DELETE FROM password_resets WHERE token = ?";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bind_param("s", $token);
    $deleteStmt->execute();
    $deleteStmt->close();

    echo json_encode(['success' => true, 'message' => 'Password reset successfully!']);
} else {
    file_put_contents('debug.log', "Failed to update password\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Failed to update password.']);
}

$stmt->close();
$conn->close();
?>
