<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Set timezone to IST
date_default_timezone_set('Asia/Kolkata');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


require 'vendor/autoload.php';  // Load Composer's autoloader

$host = 'localhost';
$username = 'root';
$password = 'n190658';
$database = 'majorproject';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['email'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input. Email is required.']);
    exit;
}

$email = trim($data['email']);

// Check if email exists
$query = "SELECT id FROM users_t WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Email not found.']);
    $stmt->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();
$user_id = $user['id'];

$stmt->close();

// Generate reset token
$token = bin2hex(random_bytes(32)); // Generate a strong random token
$expiry = date('Y-m-d H:i:s', time() + (60 * 60)); // Token expires in 1 hour

// Log current and expiry times for debugging
file_put_contents('debug.log', "Current Time: " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);
file_put_contents('debug.log', "Expiry Time: $expiry\n", FILE_APPEND);

// Store token in database
$query = "INSERT INTO password_resets (user_id, token, expiry) VALUES (?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("iss", $user_id, $token, $expiry);

if ($stmt->execute()) {
    $resetLink = "http://localhost:5173/resetPassword?token=" . $token; // Updated port number!

    // Send email with reset link
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->SMTPDebug = 0; // Enable verbose debug output (0 for no output, 2 for detailed output)
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';  // Specify your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'asdinsights1234coordinates@gmail.com'; // SMTP username
        $mail->Password   = 'skbbzxmpkxnrzmnw';    // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption, `ssl` also accepted
        $mail->Port       = 587;  // TCP port to connect to

        //Recipients
        $mail->setFrom('asdinsights1234coordinates@gmail.com', 'FetalBrainAbnormalitiesClassification Coordinates'); // Corrected setFrom
        $mail->addAddress($email);

        //Content
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset Request';
        $mail->Body    = 'Click the following link to reset your password: <a href="' . $resetLink . '">' . $resetLink . '</a>';
        $mail->AltBody = 'Copy and paste the following link into your browser: ' . $resetLink;

        if($mail->send())
        {echo json_encode(['success' => true, 'message' => 'Password reset link has been sent to your email.']);}
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Message could not be sent. Mailer Error: ' . $mail->ErrorInfo]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to store reset token.']);
}

$stmt->close();
$conn->close();
?>
